# Kent State Email Builder - Claude Code Instructions

## Overview

This workspace builds HTML email newsletters for Kent State University using a modular template system. Templates live in a shared GitHub repository; project-specific work happens here.

## Quick Start

```bash
# 1. Clone/update the shared templates (if not already done)
git clone https://github.com/[YOUR_ORG]/ksu-email-modules.git

# 2. Create a new project
mkdir projects/26XXX000
# Copy wireframe into project folder

# 3. Build the email module-by-module
# See workflow below
```

---

## Directory Structure

```
KSU_Email_Work/
├── CLAUDE.md                    # THIS FILE - read first
├── ksu-email-modules/           # Shared templates (git repo)
│   ├── modules/                 # HTML template files
│   ├── docs/                    # WORKFLOW.md, TEMPLATES.md, etc.
│   └── examples/                # Reference implementations
├── config/
│   ├── colleges.json            # College-specific configurations
│   └── test_lists.json          # Internal routing email lists
├── projects/                    # Active work
│   └── [PROJECT_ID]/
│       ├── wireframe.html       # Source from PM
│       ├── reference.html       # Similar past email (optional)
│       └── [PROJECT_ID].html    # YOUR OUTPUT
├── scripts/                     # Build automation (optional)
└── ARCHIVE/                     # Completed projects
```

---

## How to Build an Email

### Step 1: Analyze the Wireframe

1. Open `projects/[PROJECT_ID]/wireframe.html`
2. Identify each content block (featured story, story tiles, events, etc.)
3. Map blocks to modules from `ksu-email-modules/modules/`

### Step 2: Look Up Module Templates

Templates are in `ksu-email-modules/modules/`:

| Module File | Use For |
|-------------|---------|
| `00_WRAPPER_HEADER.txt` | Start of every email |
| `01_FEATURED_STORY.txt` | Hero image + 34px headline |
| `02_SECTION_DIVIDER.txt` | Grey section header bar |
| `03_STORY_TILES.txt` | 2-column alternating layout |
| `04_2X2_STORIES.txt` | 4-story grid |
| `05_STORY_BLOCK.txt` | Image left, text right |
| `06_FEATURED_EVENTS.txt` | Calendar-style listings |
| `07_HERO_STORY.txt` | Centered on grey background |
| `08_SPACER.txt` | 22px vertical spacing |
| `09_FOOTER.txt` | Social icons + contact |
| `10_DIA_EVENT_INVITE.html` | Athletics-specific template |

### Step 3: Build Module-by-Module

For each module:
1. Copy template content
2. Extract content from wireframe (images, text, URLs)
3. Replace placeholders: `{{PROJECT_ID}}`, `{{HEADLINE}}`, `{{CTA_URL}}`, etc.
4. Append to output file
5. Add spacer between modules

### Step 4: Apply College Configuration

Look up the college code (ALR, CEH, DIA, etc.) in `config/colleges.json` for:
- Header image and link
- Contact email and phone
- Social media handle
- Button style (standard gold or OGE blue)
- Footer links

### Step 5: Validate

See `ksu-email-modules/docs/QA_CHECKLIST.md`:
- [ ] All image paths match wireframe
- [ ] All copy matches wireframe exactly
- [ ] MSO conditionals on every button
- [ ] Correct college config applied

---

## Critical Rules

### 1. Extract, Don't Improvise
- **Image paths:** Copy exactly from wireframe HTML
- **Copy:** Verbatim, including typos
- **URLs:** Extract `href` values exactly

### 2. Always Use MSO Conditionals for Buttons
Every CTA button needs both:
- VML `<v:roundrect>` for Outlook
- Standard HTML button for other clients

### 3. Headline Sizes
| Module | Headline Size |
|--------|---------------|
| Featured Story | 34px bold |
| Hero Story | 24px bold |
| Story Block | 24px bold |
| Section Divider | 20px bold |

### 4. Spacers Between Modules
Add `08_SPACER.txt` between every major module EXCEPT:
- Between story tiles in the same set
- Between header and first content module

### 5. Divider Lines are Images
Never code dividers with `bgcolor`. Use:
- Gold: `dividerbar_EFAB00.png`
- Blue: `dividerbar_4994CB.png`

---

## College Quick Reference

| Code | Email | Button Style |
|------|-------|--------------|
| ALR | alumni@kent.edu | Standard (gold) |
| CEH | ehhsdean@kent.edu | Standard |
| CON | nursing@kent.edu | Standard |
| CPH | publichealth@kent.edu | Standard |
| DIA | thegoldenflashesclub@kent.edu | Standard |
| OGE | global@kent.edu | **OGE (mid-blue)** |

Full configs in `config/colleges.json`.

---

## Project ID Format

`26XXX000` where:
- `26` = Fiscal year (FY26)
- `XXX` = College code (ALR, CEH, DIA, etc.)
- `000` = Sequential number

---

## Documentation

All detailed docs are in `ksu-email-modules/docs/`:

| Document | Purpose |
|----------|---------|
| `WORKFLOW.md` | Step-by-step build process |
| `TEMPLATES.md` | Module specs + JSON schemas |
| `BRAND_STANDARDS.md` | Colors, fonts, image specs |
| `QA_CHECKLIST.md` | Validation checklist |

---

## Internal Test Routing

When routing emails for internal testing, use semicolon-separated lists from `config/test_lists.json`:

```
# Default
djporte1@kent.edu;hsommer1@kent.edu;lzimme12@kent.edu;aengelh4@kent.edu

# Unit-specific lists include the relevant PM
```

---

## Slate Deployment

Add this comment at the top of every email:
```html
<!-- SLATE SHORTCUT: https://connect.kent.edu/manage/deliver/mailing?id=GUID -->
```

Note Slate envelope info from wireframe:
- Sender name and title
- Reply-to email
- Subject line
- Preheader text (set in Slate, not HTML)

---

## Workflow Summary

```
1. mkdir projects/[PROJECT_ID]
2. Copy wireframe to project folder
3. Analyze wireframe → list modules needed
4. For each module:
   a. Copy from ksu-email-modules/modules/
   b. Replace placeholders with wireframe content
   c. Append to [PROJECT_ID].html
5. Apply college config from config/colleges.json
6. Validate against QA_CHECKLIST.md
7. Move to ARCHIVE/ when complete
```

---

*Last updated: January 2026*
